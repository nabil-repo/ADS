#include <iostream>

using namespace std;

class hashtable
{
  public:

    int table[50];
    int chain[50];
    int table_size;
    int ctr;
    hashtable(int n)
    {
        table_size = n;
        ctr = 0;
        for(int i=0;i<table_size;i++)
        {
            table[i] = -1;
            chain[i] = -1;
        }
    }
    void store_value_linear_probin_without_replacemet(int val);
    void store_value_linear_probin_with_replacemet(int val);
    void store_value_chaining_without_replacement(int val);
    void store_value_chaining_with_replacement(int val);
    void display_hash_table_linear_probing();
    void display_hash_table_chaining();
    int calculate_hash_value(int val);
    int search_value_in_hash_table_linear_probing(int val);
    int search_value_in_hash_table_chaining(int val);
};

void hashtable::store_value_chaining_with_replacement(int val)
{
    int hashvalue = calculate_hash_value(val);
    if(table[hashvalue] == -1)
    {
        table[hashvalue] = val;
        ctr++;
    }
    else
    {
        int temp_hashvalue = calculate_hash_value(table[hashvalue]);
        if(temp_hashvalue == hashvalue) // valid data is present at the location
        {
            //the location is not empty. Check the chain
            while(chain[hashvalue] != -1)
            {
                hashvalue = chain[hashvalue];
            }

            int previous_hashvalue = hashvalue;
            while(1)
            {
                hashvalue = (hashvalue + 1) % table_size;
                if(ctr == table_size)
                {
                    cout<<"\nHash table is full.  The value can not be stored";
                    break;
                }
                else if(table[hashvalue] == -1)
                {
                    table[hashvalue] = val;
                    ctr++;
                    chain[previous_hashvalue] = hashvalue;
                    break;
                }
            }
        }
        else //we have to replace the current data
        {
            int temp_data = table[hashvalue];
            int temp_hashvalue = hashvalue;
            table[hashvalue] = val;
            ctr++;
            while(chain[hashvalue] != -1)
            {
                hashvalue = chain[hashvalue];
            }

            while(1)
            {
                hashvalue = (hashvalue + 1) % table_size;
                if(ctr == table_size)
                {
                    cout<<"\n Hash table is full.  Data can not be stored";
                    break;
                }
                else if(table[hashvalue] == -1)
                {
                    table[hashvalue] = temp_data;
                    //ctr++;
                    //update the chain to previous hash value
                    chain[temp_hashvalue] = hashvalue;
                    break;
                }
            }
        }
    }
    display_hash_table_chaining();
}
void hashtable::store_value_chaining_without_replacement(int val)
{
    int hashvalue = calculate_hash_value(val);
    if(table[hashvalue] == -1)
    {
        table[hashvalue] = val;
        ctr++;
    }
    else
    {
        //the location is not empty. Check the chain
        while(chain[hashvalue] != -1)
        {
            hashvalue = chain[hashvalue];
        }

        int previous_hashvalue = hashvalue;
        while(1)
        {
            hashvalue = (hashvalue + 1) % table_size;
            if(ctr == table_size)
            {
                cout<<"\nHash table is full.  The value can not be stored";
                break;
            }
            else if(table[hashvalue] == -1)
            {
                table[hashvalue] = val;
                ctr++;
                chain[previous_hashvalue] = hashvalue;
                break;
            }
        }
    }
    display_hash_table_chaining();
}

int hashtable::search_value_in_hash_table_chaining(int val)
{
    int hashvalue = calculate_hash_value(val);
    display_hash_table_linear_probing();
    if(table[hashvalue] == val)
    {
        cout<<endl<<"The value "<<val<<" is present at location "<<hashvalue<<" in hash table";
        return hashvalue;
    }
    else if(chain[hashvalue] == -1)
    {
        cout<<"\n The value "<<val<<" is not present in hash table";
        return -1;
    }
    else
    {
        //follow the chain
        while(1)
        {
            hashvalue = chain[hashvalue];
            if(table[hashvalue] == val)
            {
                cout<<endl<<"The value "<<val<<" is present at location "<<hashvalue<<" in hash table";
                return hashvalue;
                break;
            }
            else if(chain[hashvalue] == -1)
            {
                cout<<"\n The value "<<val<<" is not present in hash table";
                return -1;
            }
        }
    }
}
int hashtable::search_value_in_hash_table_linear_probing(int val)
{
    int hashvalue = calculate_hash_value(val);
    display_hash_table_linear_probing();
    if(table[hashvalue] == val)
    {
        cout<<endl<<"The value "<<val<<" is present at location "<<hashvalue<<" in hash table";
        return hashvalue;
    }
    else
    {
        ctr = 1;
        int flag = 0;
        while(1)
        {
            hashvalue = (hashvalue + 1) % table_size;
            if(ctr == table_size)
            {
                flag = 0;
                break;
            }
            else if(table[hashvalue] == val)
            {
                flag = 1;
                break;
            }
            else if(table[hashvalue] == -1)
            {
                flag = 0;
                break;
            }
        }
        if(flag == 0)
        {
            cout<<"\n The value "<<val<<" is not present in hash table";
            return -1;
        }
        else if(flag == 1)
        {
            cout<<"\n The value "<<val<<" is present in hash table at location : "<<hashvalue;
            return hashvalue;
        }
    }
}
int hashtable::calculate_hash_value(int val)
{
    return val%table_size;
}
void hashtable::store_value_linear_probin_with_replacemet(int val)
{
    int hashvalue = calculate_hash_value(val);
    //if the location is empty
    if(table[hashvalue] == -1)
    {
        table[hashvalue] = val;
        ctr++;
    }
    else
    {
        int flag = 0;
        // from next location onward search linearly to find the empty location
        int temp_hash_value = calculate_hash_value(table[hashvalue]);
        if(temp_hash_value == hashvalue)
        {
            while(1)
            {
                hashvalue = (hashvalue + 1) %table_size;
                if(table[hashvalue] == -1)
                {
                    table[hashvalue] = val;
                    ctr++;
                    break;
                }
                else if(ctr == table_size)
                {
                    cout<<"\n The hash table is full.  The value can not be stored";
                    flag = 0;
                    break;
                }
            }
        }
        // we have to replace the data
        else
        {
            int temp_val = table[hashvalue];
            table[hashvalue] = val;
            while(1)
            {
                hashvalue = (hashvalue + 1) %table_size;
                if(table[hashvalue] == -1)
                {
                    table[hashvalue] = temp_val;
                    ctr++;
                    break;
                }
                else if(ctr == table_size)
                {
                    cout<<"\n The hash table is full.  The value can not be stored";
                    flag = 0;
                    break;
                }
            }
        }
    }
    display_hash_table_linear_probing();
}
void hashtable ::store_value_linear_probin_without_replacemet(int val)
{

    int hashvalue = calculate_hash_value(val);
    //if the location is empty
    if(table[hashvalue] == -1)
    {
        table[hashvalue] = val;
        ctr++;
    }
    else
    {
        int flag = 0;
        // from next location onward search linearly to find the empty location
        while(1)
        {
            hashvalue = (hashvalue + 1) % table_size;
            if(table[hashvalue] == -1)
            {
                table[hashvalue] = val;
                ctr++;
                break;
            }
            // else if(ctr == table_size)
            // {
            //     cout<<"\n The hash table is full.  The value can not be stored";
            //     flag = 0;
            //     break;
            // }
        }
    }
    display_hash_table_linear_probing();
}
void hashtable::display_hash_table_linear_probing()
{
    cout<<endl<<"Hash Table contains  "<<ctr<<" elements";
    for(int i=0;i<table_size;i++)
    {
        cout<<endl<<"     "<<i<<"     "<<table[i];
    }
}

void hashtable::display_hash_table_chaining()
{
    cout<<endl<<"Hash Table contains  "<<ctr<<" elements";
    for(int i=0;i<table_size;i++)
    {
        cout<<endl<<"     "<<i<<"     "<<table[i]<<"     "<<chain[i];
    }
}

int main()
{

    hashtable h(10);
    int ch, val;
    while(1)
    {
        cout<<"\n Enter the value : ";
        cin>>val;
        h.store_value_chaining_without_replacement(val);
        cout<<"\n Do you want to enter other value (0/1) : ";
        cin>>ch;
        if(ch == 0)
            break;
    }
    while(1)
    {
        cout<<"\n Enter the value to be searched: ";
        cin>>val;
        h.search_value_in_hash_table_chaining(val);
        cout<<"\n Do you want to search other value (0/1) : ";
        cin>>ch;
        if(ch == 0)
            break;
    }

    return 0;
}
