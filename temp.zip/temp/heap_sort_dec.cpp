#include <iostream>
using namespace std;

class heapp
{
public:
    int heap[20];
    int heap_size;

    heapp()
    {
        heap_size = 0;
    }

    void insert_heap(int val);
    void up_heapify();
    void delete_heap();
    void down_heapify();
};

void heapp::insert_heap(int val)
{
    heap_size++;
    heap[heap_size] = val;
    up_heapify();
}

void heapp::up_heapify()
{

    int cur_loc, parent_loc;
    cur_loc = heap_size;
    while (cur_loc != 1)
    {
        parent_loc = (cur_loc) / 2;

        if (heap[parent_loc] >= heap[cur_loc])
        {
            int temp = heap[parent_loc];
            heap[parent_loc] = heap[cur_loc];
            heap[cur_loc] = temp;
            cur_loc = parent_loc;
        }
        else
        {
            break;
        }
    }
}
void heapp::delete_heap()
{
    swap(heap[1], heap[heap_size]);
    heap_size--;
    down_heapify();
}

void heapp::down_heapify()
{
    int cur_loc = 1, loc_left, loc_right;

    while (1)
    {
        loc_left = cur_loc * 2;
        loc_right = (cur_loc * 2) + 1;

        if (loc_left <= heap_size && loc_right <= heap_size)
        {
            if (heap[loc_left] < heap[loc_right])
            {
                if (heap[cur_loc] > heap[loc_left])
                {
                    swap(heap[cur_loc], heap[loc_left]);
                    cur_loc = loc_left;
                }
                else
                {
                    break;
                }
            }
            else
            {
                if (heap[cur_loc] > heap[loc_right])
                {
                    swap(heap[cur_loc], heap[loc_right]);
                    cur_loc = loc_right;
                }
                else
                {
                    break;
                }
            }
        }
        else if (loc_left <= heap_size)
        {
            if (heap[cur_loc] > heap[loc_left])
            {
                swap(heap[cur_loc], heap[loc_left]);
                cur_loc = loc_left;
            }
            else
            {
                break;
            }
        }
        else
        {
            break;
        }
    }
}

int main()
{
    int n, no;
    heapp h;
    cout << "Enter the number of elements: ";
    cin >> n;

    for (int i = 0; i < n; i++)
    {
        cout << "\n Enter  element: ";
        cin >> no;
        h.insert_heap(no);
    }

    while (h.heap_size != 1)
    {
        h.delete_heap();
    }
    cout << endl;

    for (int i = 1; i <= n; i++)
    {
        cout << "\t " << h.heap[i] << endl;
    }

    return 0;
}
