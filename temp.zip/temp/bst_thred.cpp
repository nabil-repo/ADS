#include <iostream>
#include <stack>

using namespace std;

class node
{
public:
    int data;
    node *left;
    node *right;
    int lth;
    int rth;
};
class threadedbst
{
public:
    node *root;

    void create_bst()
    {

        root = NULL;
        int ch;
        int no;
        do
        {
            cout << "Enter the the number" << endl;
            cin >> no;

            if (root == NULL)
            {
                root = new node();
                root->data = no;
                root->left = NULL;
                root->right = NULL;
                root->lth = 1;
                root->rth = 1;
            }
            else
            {
                node *temp = root;

                while (1)
                {
                    if (temp->data < no)
                    {
                        if (temp->rth == 0)
                        {

                            temp = temp->right;
                        }
                        else
                        {
                            // attach right
                            node *t = new node();
                            t->data = no;
                            temp->rth = 0;
                            t->left = temp;
                            t->right = temp->right;
                            t->lth = 1;
                            t->rth = 1;
                            
                            temp->right = t;
                            break;
                        }
                    }
                    else
                    {
                        if (temp->lth == 0)
                        {

                            temp = temp->left;
                        }
                        else
                        {
                            // attach left
                            node *t = new node();
                            t->data = no;
                            temp->lth = 0;
                            t->left = temp->left;
                            t->right = temp;
                            t->lth = 1;
                            t->rth = 1;
                            
                            temp->left = t;
                            break;
                        }
                    }
                }
            }
            cout << "Do you want to enter the another number:" << endl;
            cin >> ch;
        } while (ch != 0);
    }

    void non_rec_inorder()
    {
        node *t = root;
        while (t->lth == 0)
        {
            t = t->left;
        }
        cout << " " << t->data;

        while (1)
        {
            if (t->rth == 1)
            {
                t = t->right;
            }
            else
            {
                t = t->right;

                while (t->lth == 0)
                {
                    t = t->left;
                }
            }

            if (t != NULL)
                cout << " " << t->data;
            else
                break;
        }
    }

    void non_rec_preorder()
    {
        node *t = root;
        while (t != NULL)
        {
            while (t->lth == 0)
            {
                cout << " " << t->data;
                t = t->left;
            }
            cout << " " << t->data;

            while (t->rth == 1)
            {
                t = t->right;
                if (t == NULL)
                    break;
            }

            if (t != NULL)
                t = t->right;

            if (t == NULL)
            {
                break;
            }
        }
    }

    void non_rec_postorder()
    {
        if (root == NULL)
            return;

        stack<node *> s1, s2;
        s1.push(root);

        while (!s1.empty())
        {
            node *t = s1.top();
            s1.pop();
            s2.push(t);

            if (t->lth == 0)
                s1.push(t->left);
            if (t->rth == 0)
                s1.push(t->right);
        }

        while (!s2.empty())
        {
            cout << " " << s2.top()->data;
            s2.pop();
        }
    }

    void rec_inorder(node *temp)
    {
        if (temp != NULL)
        {
            if (temp->lth == false)
                rec_inorder(temp->left);
            cout << " " << temp->data;
            if (temp->rth == false)
                rec_inorder(temp->right);
        }
    }

    void rec_preorder(node *temp)
    {
        if (temp != NULL)
        {
            cout << temp->data << " ";
            if (temp->lth == 0)
                rec_preorder(temp->left);
            if (temp->rth == 0)
                rec_preorder(temp->right);
        }
    }
    void rec_postorder(node *temp)
    {
        if (temp != NULL)
        {
            if (temp->lth == 0)
                rec_postorder(temp->left);
            if (temp->rth == 0)
                rec_postorder(temp->right);
            cout << temp->data << " ";
        }
    }
};

int main()
{
    threadedbst obj;
    obj.create_bst();

    cout << "Non rec-Inorder: ";
    obj.non_rec_inorder();
    cout << endl;
    cout << "Non rec pre-order: ";
    obj.non_rec_preorder();
    cout << endl;
    cout << "Non rec post-order: ";
    obj.non_rec_postorder();
    cout << endl;

    cout << "Inorder: ";
    obj.rec_inorder(obj.root);
    cout << endl;
    cout << "Preorder: ";
    obj.rec_preorder(obj.root);
    cout << endl;
    cout << "Post order: ";
    obj.rec_postorder(obj.root);

    return 0;
}