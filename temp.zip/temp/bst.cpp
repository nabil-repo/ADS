#include <iostream>

using namespace std;

class node
{
public:
    int data;
    node *next;
};


class treenode
{
public:
    int data;
    treenode *left;
    treenode *right;
};

class bst
{
public:
    treenode *root = NULL;

    void create_bst()
    {
        int no, ch;

        do
        {
            cout << "Enter the data:";
            cin >> no;

            if (root == NULL)
            {
                root = new treenode();
                root->data = no;
                root->left = NULL;
                root->right = NULL;
            }
            else
            {
                treenode *t = root;

                while (1)
                {
                    if (t->data < no)
                    {
                        // right
                        if (t->right == NULL)
                        {
                            treenode *newnode = new treenode();
                            newnode->data = no;
                            newnode->left = NULL;
                            newnode->right = NULL;
                            t->right = newnode;
                            break;
                        }
                        else
                        {
                            t = t->right;
                        }
                    }
                    else if (t->data > no)
                    {
                        // left
                        if (t->left == NULL)
                        {
                            treenode *newnode = new treenode();
                            newnode->data = no;
                            newnode->left = NULL;
                            newnode->right = NULL;
                            t->left = newnode;
                            break;
                        }
                        else
                        {
                            t = t->left;
                        }
                    }
                }
            }
            cout << "Enter 1 to continue,0 to exit:";
            cin >> ch;
        } while (ch != 0);
    }

    void inorder()
    {
        treenode *t = root;
        do_inorder(t);
    }

    void do_inorder(treenode *t)
    {
        if (t != NULL)
        {
            do_inorder(t->left);
            cout << t->data << " ";
            do_inorder(t->right);
        }
    }

    void preorder()
    {
        treenode *t = root;
        do_preorder(t);
    }

    void do_preorder(treenode *t)
    {
        if (t != NULL)
        {
            cout << t->data << " ";
            do_preorder(t->left);
            do_preorder(t->right);
        }
    }

    void postorder()
    {
        treenode *t = root;
        do_postorder(t);
    }

    void do_postorder(treenode *t)
    {
        if (t != NULL)
        {
            do_postorder(t->left);
            do_postorder(t->right);
            cout << t->data << " ";
        }
    }
};

int main()
{
    bst s;
    s.create_bst();

    cout << "INORDER: ";
    s.inorder();

    cout << "\nPREORDER: ";
    s.preorder();

    cout << "\nPOSTORDER: ";
    s.postorder();

    return 0;
}