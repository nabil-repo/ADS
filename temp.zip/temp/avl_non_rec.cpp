#include <iostream>
#include <stack>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) : data(val), left(nullptr), right(nullptr) {}
};

class AVLTree {
public:
    Node* root;

    AVLTree() {
        root = nullptr;
    }

    // Function to create a new node
    Node* createNode(int data) {
        return new Node(data);
    }

    // Function to insert a node into the AVL tree
    Node* insert(Node* node, int data) {
        if (node == nullptr)
            return createNode(data);

        if (data < node->data)
            node->left = insert(node->left, data);
        else if (data > node->data)
            node->right = insert(node->right, data);
        else // Duplicate keys are not allowed
            return node;

        return node;
    }

    // Function to perform non-recursive inorder traversal
    void inorderNonRecursive(Node* root) {
        if (root == nullptr)
            return;

        stack<Node*> s;
        Node* curr = root;

        while (curr != nullptr || !s.empty()) {
            while (curr != nullptr) {
                s.push(curr);
                curr = curr->left;
            }

            curr = s.top();
            s.pop();
            cout << curr->data << " ";

            curr = curr->right;
        }
    }

    // Function to perform non-recursive preorder traversal
    void preorderNonRecursive(Node* root) {
        if (root == nullptr)
            return;

        stack<Node*> s;
        s.push(root);

        while (!s.empty()) {
            Node* curr = s.top();
            s.pop();
            cout << curr->data << " ";

            if (curr->right)
                s.push(curr->right);
            if (curr->left)
                s.push(curr->left);
        }
    }

    // Function to perform non-recursive postorder traversal
    void postorderNonRecursive(Node* root) {
        if (root == nullptr)
            return;

        stack<Node*> s;
        Node* curr = root;

        do {
            while (curr) {
                if (curr->right)
                    s.push(curr->right);
                s.push(curr);
                curr = curr->left;
            }

            curr = s.top();
            s.pop();

            if (curr->right && !s.empty() && s.top() == curr->right) {
                s.pop();
                s.push(curr);
                curr = curr->right;
            } else {
                cout << curr->data << " ";
                curr = nullptr;
            }
        } while (!s.empty());
    }
};

int main() {
    AVLTree avl;
    int choice, numElements, data;

    cout << "Enter the number of elements in the AVL tree: ";
    cin >> numElements;

    cout << "Enter the elements of the AVL tree:\n";
    for (int i = 0; i < numElements; ++i) {
        cin >> data;
        avl.root = avl.insert(avl.root, data);
    }

    do {
        cout << "\nAVL Tree Operations\n";
        cout << "1. Non-recursive Inorder Traversal\n";
        cout << "2. Non-recursive Preorder Traversal\n";
        cout << "3. Non-recursive Postorder Traversal\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Non-recursive Inorder Traversal: ";
                avl.inorderNonRecursive(avl.root);
                cout << endl;
                break;
            case 2:
                cout << "Non-recursive Preorder Traversal: ";
                avl.preorderNonRecursive(avl.root);
                cout << endl;
                break;
            case 3:
                cout << "Non-recursive Postorder Traversal: ";
                avl.postorderNonRecursive(avl.root);
                cout << endl;
                break;
            case 4:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice\n";
        }
    } while (choice != 4);

    return 0;
}