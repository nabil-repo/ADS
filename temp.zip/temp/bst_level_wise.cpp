#include <iostream>

using namespace std;

class node

{
public:
    int data;
    node *next;
    node *left;
    node *right;
};

class ququenode
{
public:
    node *addr;
    ququenode *next;
};
class myqueue
{
public:
    ququenode *front = NULL;
    ququenode *rear = NULL;

    void add_queue(node *addr)
    {
        if (rear == NULL)
        {
            rear = new ququenode();
            rear->addr = addr;
            rear->next = NULL;
            front = rear;
        }
        else
        {
            ququenode *t = new ququenode();
            t->addr = addr;
            t->next = NULL;
            rear->next = t;
            rear = t;
        }
    }
    node *delete_node()
    {
        ququenode *t = front;
        node *addr = t->addr;
        front = front->next;
        if (front == NULL)
            rear = NULL;
        delete t;
        return addr;
    }
    int queue_empty()
    {
        if (front == NULL && rear == NULL)
            return 1;
        else
            return 0;
    }
};

void level_wise()
{
    node *root = new node();
    root->data = 10;
    root->left = new node();
    root->left->data = 5;

    root->right = new node();
    root->right->data = 15;

    root->left->left = new node();
    root->left->left->data = 3;

    root->left->right = new node();
    root->left->right->data = 8;

    root->right->left = new node();
    root->right->left->data = 12;

    root->right->right = new node();
    root->right->right->data = 20;

    myqueue q1;
    node *curr = root;
    q1.add_queue(curr);

    node *marker = new node();
    marker->data = -999;
    marker->left = NULL;
    marker->right = NULL;

    q1.add_queue(marker);

    int flag = 0;

    cout << endl;
    while (!q1.queue_empty())
    {
        curr = q1.delete_node();
        if (curr->data != -999)
        {
            if (flag > 0)
                flag--;
            cout << " " << curr->data;
            if (curr->left != NULL)
                q1.add_queue(curr->left);
            if (curr->right != NULL)
                q1.add_queue(curr->right);
        }
        else
        {
            flag++;
            if (flag == 2)
                break;
            q1.add_queue(marker);
            cout << endl;
        }
    }
}



int main()
{

    level_wise();
}