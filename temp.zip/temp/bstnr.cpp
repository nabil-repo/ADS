#include <iostream>
using namespace std;

class TreeNode;

class Node
{
public:
    TreeNode *data;
    Node *next;
};

class TreeNode
{
public:
    int data;
    TreeNode *left;
    TreeNode *right;
};

class MyStack
{
public:
    Node *head = NULL;

    void push(TreeNode *no)
    {
        if (head == NULL)
        {
            head = new Node();
            head->data = no;
            head->next = NULL;
        }
        else
        {
            Node *temp = new Node();
            temp->data = no;
            temp->next = head;
            head = temp;
        }
    }

    TreeNode *pop()
    {
        if (head != NULL)
        {
            Node *t = head;
            TreeNode *data = t->data;
            head = head->next;
            delete t;
            return data;
        }
        return NULL;
    }

    int is_Stack_Empty()
    {
        return head == NULL ? 1 : 0;
    }
};



class BST
{
public:
    TreeNode *Root = NULL;

    void createBst()
    {
        int no;
        int choice;
        do
        {
            cout << "Enter the number: ";
            cin >> no;
            if (Root == NULL)
            {
                Root = new TreeNode();
                Root->data = no;
                Root->left = NULL;
                Root->right = NULL;
            }
            else
            {
                TreeNode *t = Root;
                while (true)
                {
                    if (t->data < no)
                    {
                        if (t->right == NULL)
                        {
                            TreeNode *t1 = new TreeNode();
                            t1->data = no;
                            t1->right = NULL;
                            t1->left = NULL;
                            t->right = t1;
                            break;
                        }
                        else
                        {
                            t = t->right;
                        }
                    }
                    else
                    {
                        if (t->left == NULL)
                        {
                            TreeNode *t1 = new TreeNode();
                            t1->data = no;
                            t1->right = NULL;
                            t1->left = NULL;
                            t->left = t1;
                            break;
                        }
                        else
                        {
                            t = t->left;
                        }
                    }
                }
            }
            cout << "Do you want to continue(1=y/0=n)?: ";
            cin >> choice;
        } while (choice == 1);
    }

    void non_recursive_inorder()
    {
        MyStack s1;
        TreeNode *curr = Root;

        while (curr != NULL || !s1.is_Stack_Empty())
        {
            while (curr != NULL)
            {
                s1.push(curr);
                curr = curr->left;
            }

            curr = s1.pop();
            cout << curr->data << " ";

            curr = curr->right;
        }
    }

    void non_recursive_preorder()
    {
        MyStack s1;
        TreeNode *curr = Root;
        s1.push(curr);

        while (!s1.is_Stack_Empty())
        {

            curr = s1.pop();
            cout << curr->data << " ";

            if (curr->right != NULL)
            {
                s1.push(curr->right);
            }
            if (curr->left != NULL)
            {
                s1.push(curr->left);
            }
        }
    }

    void non_recursive_postorder()
    {
        MyStack s1, s2;
        TreeNode *curr = Root;
        TreeNode *temp;

        s1.push(curr);

        while (!s1.is_Stack_Empty())
        {
            temp = s1.pop();
            s2.push(temp);

            if (temp->left != NULL)
            {
                s1.push(temp->left);
            }

            if (temp->right != NULL)
            {
                s1.push(temp->right);
            }
        }
        while (!s2.is_Stack_Empty())
        {
            temp = s2.pop();
            cout << temp->data << " ";
        }
    }
};

int main()
{
    BST b;
    b.createBst();
    cout << "Non-recursive inorder traversal: ";
    b.non_recursive_inorder();
    cout << "\nNon-recursive preorder traversal: ";
    b.non_recursive_preorder();
    cout << "\nNon-recursive postorder traversal: ";
    b.non_recursive_postorder();
    return 0;
}