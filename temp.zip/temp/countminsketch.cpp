#include <iostream>

using namespace std;

class countminsketch
{
  public:
    int hashtable1[10];
    int hashtable2[10];
    int hashtable3[10];
    int hashtable4[10];

    countminsketch()
    {
        for(int i=0;i<10;i++)
        {
            hashtable1[i] = 0;
            hashtable2[i] = 0;
            hashtable3[i] = 0;
            hashtable4[i] = 0;
        }
    }

    int hashfunction1(int val)
    {
        return (val*2+2)%10;
    }

    int hashfunction2(int val)
    {
        return (val*3+3)%10;
    }

    int hashfunction3(int val)
    {
        return (val*4+4)%10;
    }

    int hashfunction4(int val)
    {
        return (val*5+5)%10;
    }

    int convert_string_to_number(string s)
    {
        int ans = 0;
        int len = s.length();
        int i=0; 

        for(i=0;i<len;++i)
        {
            cout<<endl<<s[i]<<"   "<<(int)s[i];
            ans += (int)s[i]; 
        }
        return ans;
    }

    void store_values(string s)
    {
        int num = convert_string_to_number(s);
        cout<<endl<<"The number is : "<<num;
       
;
        
         print_hash_tables();
         
        int h1 = hashfunction1(num);
        int h2 = hashfunction2(num);
        int h3 = hashfunction3(num);
        int h4 = hashfunction4(num);
        
         cout<<endl<<"The hash values are: h1 => "<<h1<<"  h2 => "<<h2<<"  h3 => "<<h3<<"  h4 => "<<h4;

        hashtable1[h1]++;
        hashtable2[h2]++;
        hashtable3[h3]++;
        hashtable4[h4]++;

        print_hash_tables();

    }

    void get_count(string s)
    {
        int num = convert_string_to_number(s);
        int h1 = hashfunction1(num);
        int h2 = hashfunction2(num);
        int h3 = hashfunction3(num);
        int h4 = hashfunction4(num);

        cout<<endl<<"The data is: "<<s;
        cout<<endl<<"The hash values are: h1 => "<<h1<<"  h2 => "<<h2<<"  h3 => "<<h3<<"  h4 => "<<h4;
;
        print_hash_tables();
        int arr[4];

        arr[0] = hashtable1[h1];
        arr[1] = hashtable2[h2];
        arr[2] = hashtable3[h3];
        arr[3] = hashtable4[h4];

        int min = 9999;

        for(int i=0; i<4;i++)
        {
            if(arr[i]<min)
                min = arr[i];
        }

        cout<<endl<<"The data has already been received "<<min<<" times";        
    }

    void print_hash_tables()
    {
        cout<<endl<<"Hash Table 1"<<endl;
        for(int i=0;i<10;i++)
        {
            cout<<"   "<<hashtable1[i];
        }
        cout<<endl;

        cout<<endl<<"Hash Table 2"<<endl;
        for(int i=0;i<10;i++)
        {
            cout<<"   "<<hashtable2[i];
        }
        cout<<endl;

        cout<<endl<<"Hash Table 3"<<endl;
        for(int i=0;i<10;i++)
        {
            cout<<"   "<<hashtable3[i];
        }
        cout<<endl;

        cout<<endl<<"Hash Table 4"<<endl;
        for(int i=0;i<10;i++)
        {
            cout<<"   "<<hashtable4[i];
        }
        cout<<endl;
    }
};

int main()
{
    int ans = 1;
    string data;
    countminsketch c;
    do{
        cout<<endl<<"Enter the data: ";
        cin>>data;
        c.store_values(data);
        cout<<endl<<"Do you want to enter other data (0/1)";
        cin>>ans;
    }while(ans != 0);

    do{
        cout<<endl<<"Enter the data for search: ";
        cin>>data;
        c.get_count(data);
        cout<<endl<<"Do you want to search other data (0/1)";
        cin>>ans;
    }while(ans != 0);

    return 0;
}
