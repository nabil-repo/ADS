#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
};

class AVLTree {
public:
    Node* root;

    AVLTree() {
        root = nullptr;
    }

    // Function to create a new node
    Node* createNode(int data) {
        Node* newNode = new Node();
        newNode->data = data;
        newNode->left = nullptr;
        newNode->right = nullptr;
        return newNode;
    }

    // Function to insert a node into the AVL tree
    Node* insert(Node* node, int data) {
        if (node == nullptr)
            return createNode(data);

        if (data < node->data)
            node->left = insert(node->left, data);
        else if (data > node->data)
            node->right = insert(node->right, data);
        else // Duplicate keys are not allowed
            return node;

        return node;
    }

    // Function to perform recursive inorder traversal
    void inorderRecursive(Node* root) {
        if (root == nullptr)
            return;

        inorderRecursive(root->left);
        cout << root->data << " ";
        inorderRecursive(root->right);
    }

    // Function to perform recursive preorder traversal
    void preorderRecursive(Node* root) {
        if (root == nullptr)
            return;

        cout << root->data << " ";
        preorderRecursive(root->left);
        preorderRecursive(root->right);
    }

    // Function to perform recursive postorder traversal
    void postorderRecursive(Node* root) {
        if (root == nullptr)
            return;

        postorderRecursive(root->left);
        postorderRecursive(root->right);
        cout << root->data << " ";
    }
};

int main() {
    AVLTree avl;
    int choice, numElements, data;

    cout << "Enter the number of elements in the AVL tree: ";
    cin >> numElements;

    cout << "Enter the elements of the AVL tree:\n";
    for (int i = 0; i < numElements; ++i) {
        cin >> data;
        avl.root = avl.insert(avl.root, data);
    }

    do {
        cout << "\nAVL Tree Operations\n";
        cout << "1. Recursive Inorder Traversal\n";
        cout << "2. Recursive Preorder Traversal\n";
        cout << "3. Recursive Postorder Traversal\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Recursive Inorder Traversal: ";
                avl.inorderRecursive(avl.root);
                cout << endl;
                break;
            case 2:
                cout << "Recursive Preorder Traversal: ";
                avl.preorderRecursive(avl.root);
                cout << endl;
                break;
            case 3:
                cout << "Recursive Postorder Traversal: ";
                avl.postorderRecursive(avl.root);
                cout << endl;
                break;
            case 4:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice\n";
        }
    } while (choice != 4);

    return 0;
}